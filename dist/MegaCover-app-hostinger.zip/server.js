// MegaCover Pro Elite: entrega o site (pasta public/). Toda a lógica de planos fica no Supabase.
const express = require("express");
const path = require("path");
const app = express();
const PUB = path.join(__dirname, "public");

app.disable("x-powered-by");
app.use((req, res, next) => {
  res.set({"X-Content-Type-Options": "nosniff", "Referrer-Policy": "strict-origin-when-cross-origin", "X-Frame-Options": "SAMEORIGIN"});
  next();
});
// endereços limpos: /planos → planos.html, /conta → conta.html, /app → app.html
app.use(express.static(PUB, {
  extensions: ["html"],
  setHeaders(res, arquivo) {
    if (arquivo.endsWith(".json")) res.set("Cache-Control", "public, max-age=600");
    else if (!arquivo.endsWith(".html")) res.set("Cache-Control", "public, max-age=3600");
  },
}));
app.use((req, res) => res.status(404).sendFile(path.join(PUB, "index.html")));

const PORTA = process.env.PORT || 3000;
app.listen(PORTA, () => console.log("MegaCover no ar na porta " + PORTA));
